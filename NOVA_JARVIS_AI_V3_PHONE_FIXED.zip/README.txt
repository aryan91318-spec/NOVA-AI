NOVA JARVIS AI V3 — PHONE FIX
================================

WHY YOUR SCREEN SHOWED "content://media/external/"
---------------------------------------------------
That means Android opened index.html directly from the file manager.
The AI endpoint (/api/chat) and the microphone server are NOT running in
that mode. This causes:
  - "Failed to fetch"
  - microphone/secure-context problems

THIS V3 FIX
-----------
Do NOT open public/index.html directly.

ON ANDROID (TERMUX)
-------------------
1. Install/open Termux.
2. Put/extract this whole folder somewhere Termux can access.
3. In Termux, enter the folder.
4. First time only:
     pkg update
     pkg install python -y
5. Copy .env.example to .env:
     cp .env.example .env
6. Edit .env and put:
     OPENAI_API_KEY=your_secret_key
     OPENAI_MODEL=the_current_model_id_available_to_you
7. Start:
     bash START.sh
8. Keep Termux running.
9. Open Chrome and type EXACTLY:
     http://127.0.0.1:3000
10. Allow microphone permission.
11. Now type "Hi" or tap the microphone.

IMPORTANT
---------
- The browser must show http://127.0.0.1:3000 in the address bar.
- It must NOT show content://media/external/...
- It must NOT show file://...
- Do not close Termux while using NOVA JARVIS.
- Never put the API key inside index.html.

IF YOU GET AN OPENAI ERROR
--------------------------
The server is working if NOVA JARVIS opens at 127.0.0.1:3000.
An OpenAI error after that usually means the API key/model setting is wrong.
Check .env.

SECURITY
--------
The API key stays server-side in .env. Do not share the .env file publicly.
