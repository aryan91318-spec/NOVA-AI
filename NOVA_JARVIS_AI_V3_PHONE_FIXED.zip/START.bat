@echo off
cd /d "%~dp0"
echo NOVA JARVIS AI V3
where python >nul 2>nul
if errorlevel 1 (
  echo Python is required. Install Python 3 first.
  pause
  exit /b 1
)
if not exist .env copy .env.example .env
python server.py
pause
