import os, json, urllib.request, urllib.error
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT=Path(__file__).parent
PORT=int(os.environ.get("PORT","3000"))
API_KEY=os.environ.get("OPENAI_API_KEY","")
MODEL=os.environ.get("OPENAI_MODEL","")

def load_env():
    p=ROOT/".env"
    if p.exists():
        for line in p.read_text(encoding="utf-8").splitlines():
            line=line.strip()
            if not line or line.startswith("#") or "=" not in line: continue
            k,v=line.split("=",1)
            os.environ.setdefault(k.strip(),v.strip().strip('"').strip("'"))
load_env()
API_KEY=os.environ.get("OPENAI_API_KEY","")
MODEL=os.environ.get("OPENAI_MODEL","")

class Handler(BaseHTTPRequestHandler):
    def send_json(self, code, obj):
        b=json.dumps(obj,ensure_ascii=False).encode()
        self.send_response(code);self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Content-Length",str(len(b)));self.end_headers();self.wfile.write(b)
    def do_POST(self):
        if self.path!="/api/chat": self.send_json(404,{"error":"Not found"});return
        if not API_KEY: self.send_json(500,{"error":"OPENAI_API_KEY .env में नहीं है"});return
        if not MODEL: self.send_json(500,{"error":"OPENAI_MODEL .env में नहीं है"});return
        try:
            n=int(self.headers.get("Content-Length","0")); body=json.loads(self.rfile.read(n))
            msgs=body.get("messages",[])[-20:]
            payload={"model":MODEL,"instructions":"You are NOVA JARVIS, a helpful assistant. Reply naturally and concisely. Prefer Hindi/Hinglish when the user does. Call the user Boss when appropriate.","input":[{"role":"assistant" if m.get("role")=="assistant" else "user","content":str(m.get("content",""))} for m in msgs]}
            req=urllib.request.Request("https://api.openai.com/v1/responses",data=json.dumps(payload).encode(),headers={"Authorization":"Bearer "+API_KEY,"Content-Type":"application/json"},method="POST")
            with urllib.request.urlopen(req,timeout=60) as r: data=json.loads(r.read().decode())
            self.send_json(200,{"reply":data.get("output_text","")})
        except urllib.error.HTTPError as e:
            try: detail=json.loads(e.read().decode()).get("error",{}).get("message","OpenAI API error")
            except: detail="OpenAI API error"
            self.send_json(e.code,{"error":detail})
        except Exception as e: self.send_json(500,{"error":str(e)})
    def do_GET(self):
        path=self.path.split("?")[0]
        if path=="/":path="/index.html"
        f=ROOT/"public"/path.lstrip("/")
        if not f.exists() or not f.is_file(): self.send_error(404);return
        data=f.read_bytes();self.send_response(200)
        self.send_header("Content-Type","text/html; charset=utf-8" if f.suffix==".html" else "text/plain")
        self.send_header("Content-Length",str(len(data)));self.end_headers();self.wfile.write(data)
    def log_message(self,*args): pass

print("NOVA JARVIS: http://localhost:%d"%PORT)
print("Open in Chrome: http://127.0.0.1:%d" % PORT)
ThreadingHTTPServer(("127.0.0.1",PORT),Handler).serve_forever()
