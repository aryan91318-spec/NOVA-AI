#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")"
echo ""
echo "===================================="
echo "       NOVA JARVIS AI V3"
echo "===================================="
echo ""
if ! command -v python >/dev/null 2>&1; then
  echo "Python is not installed."
  echo "Run: pkg update && pkg install python -y"
  echo ""
  read -r -p "Press Enter after installing Python..."
fi
if [ ! -f ".env" ]; then
  cp .env.example .env
  echo "Created .env"
  echo "IMPORTANT: edit .env and put your API key + current model ID."
fi
echo ""
echo "Starting NOVA JARVIS..."
echo "Open Chrome: http://127.0.0.1:3000"
echo "Keep this Termux screen running."
echo ""
python server.py
