package com.nova.ai

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var answerText: TextView
    private lateinit var heardText: TextView
    private lateinit var statusText: TextView
    private lateinit var commandInput: EditText
    private lateinit var tts: TextToSpeech
    private var speechRecognizer: SpeechRecognizer? = null

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startListening()
            else speak("Microphone permission is required for voice commands.")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        answerText = findViewById(R.id.answerText)
        heardText = findViewById(R.id.heardText)
        statusText = findViewById(R.id.statusText)
        commandInput = findViewById(R.id.commandInput)

        tts = TextToSpeech(this, this)

        findViewById<Button>(R.id.micButton).setOnClickListener {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
                micPermission.launch(Manifest.permission.RECORD_AUDIO)
            } else {
                startListening()
            }
        }

        findViewById<Button>(R.id.youtubeButton).setOnClickListener {
            openYouTube()
        }

        findViewById<Button>(R.id.searchButton).setOnClickListener {
            val q = commandInput.text.toString().trim()
            if (q.isEmpty()) {
                speak("Type what you want to search on YouTube.")
            } else {
                searchYouTube(q)
            }
        }

        commandInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE ||
                actionId == EditorInfo.IME_ACTION_GO) {
                runCommand(commandInput.text.toString())
                true
            } else false
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Speech recognition is not available on this phone.")
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)

        speechRecognizer?.setRecognitionListener(
            object : android.speech.RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    statusText.text = "Listening..."
                }

                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    statusText.text = "Processing..."
                }

                override fun onError(error: Int) {
                    statusText.text = "Ready"
                    speak("I could not hear that. Please try again.")
                }

                override fun onResults(results: Bundle?) {
                    val list = results?.getStringArrayList(
                        SpeechRecognizer.RESULTS_RECOGNITION
                    )
                    val text = list?.firstOrNull().orEmpty()
                    statusText.text = "Ready"
                    heardText.text = "You: $text"
                    runCommand(text)
                }

                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            }
        )

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Talk to NOVA")
        }

        speechRecognizer?.startListening(intent)
    }

    private fun runCommand(raw: String) {
        val text = raw.lowercase(Locale.getDefault()).trim()

        when {
            text.contains("open youtube") ||
            text.contains("youtube खोल") ||
            text.contains("यूट्यूब खोल") -> {
                speak("Opening YouTube.")
                openYouTube()
            }

            text.contains("search youtube") ||
            text.contains("youtube search") ||
            text.contains("यूट्यूब पर खोज") ||
            text.contains("यूट्यूब पर सर्च") -> {
                val query = extractSearchQuery(raw)
                if (query.isBlank()) {
                    speak("What should I search on YouTube?")
                } else {
                    speak("Searching YouTube for $query.")
                    searchYouTube(query)
                }
            }

            text.contains("open google") ||
            text.contains("गूगल खोल") -> {
                speak("Opening Google.")
                openUrl("https://www.google.com")
            }

            text == "hello" || text.contains("hello nova") ||
            text.contains("हेलो") || text.contains("नमस्ते") -> {
                speak("Hello! I am NOVA. How can I help?")
            }

            text.contains("what can you do") ||
            text.contains("तुम क्या कर सकते") -> {
                speak("I can open YouTube, search YouTube, open Google, and respond to simple commands.")
            }

            else -> {
                answerText.text = "I heard: $raw"
                speak("I heard you say $raw. This command is not added yet.")
            }
        }
    }

    private fun extractSearchQuery(raw: String): String {
        val lower = raw.lowercase(Locale.getDefault())
        val markers = listOf(
            "search youtube for",
            "search youtube",
            "youtube search for",
            "youtube search",
            "यूट्यूब पर सर्च करो",
            "यूट्यूब पर सर्च",
            "यूट्यूब पर खोजो",
            "यूट्यूब पर खोज"
        )

        for (marker in markers) {
            val index = lower.indexOf(marker.lowercase(Locale.getDefault()))
            if (index >= 0) {
                return raw.substring(index + marker.length).trim()
            }
        }
        return raw.trim()
    }

    private fun openYouTube() {
        try {
            val appIntent = packageManager.getLaunchIntentForPackage("com.google.android.youtube")
            if (appIntent != null) {
                startActivity(appIntent)
            } else {
                openUrl("https://www.youtube.com/")
            }
        } catch (_: Exception) {
            openUrl("https://www.youtube.com/")
        }
    }

    private fun searchYouTube(query: String) {
        val url = "https://www.youtube.com/results?search_query=" +
                Uri.encode(query)
        openUrl(url)
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "No browser found.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.getDefault()
            tts.setSpeechRate(0.95f)
        }
    }

    private fun speak(message: String) {
        answerText.text = message
        if (::tts.isInitialized) {
            tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "NOVA")
        }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
