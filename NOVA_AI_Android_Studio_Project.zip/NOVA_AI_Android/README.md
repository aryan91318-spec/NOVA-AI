# NOVA AI — Android Starter

A safe Android voice-assistant starter project.

## Included
- Voice input using Android SpeechRecognizer
- Text-to-speech replies
- Open YouTube
- Search YouTube
- Open Google
- Simple command parser
- Black + crimson UI
- No malware, virus, hidden access, or destructive commands

## Build
Open this folder in Android Studio.
Let Gradle sync, then Run on an Android phone.

Recommended:
- Android Studio recent stable version
- Android SDK 35
- JDK 17 for this Gradle/AGP setup

## Important
This is an assistant starter, not a full LLM. For natural-language AI answers, connect a legitimate AI API from a secure backend rather than putting a secret API key directly inside the APK.

The app only performs the actions explicitly implemented in MainActivity.kt and asks for microphone permission when voice input is used.
